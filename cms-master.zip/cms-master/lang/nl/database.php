<?php

return [
    'fields_not_accepted' => 'Kolom :field is niet geaccepteerd in het verzoek.',
];
