<?php

return [
    'fields_not_accepted' => 'الحقول :field غير مقبولة فى البحث',
];
