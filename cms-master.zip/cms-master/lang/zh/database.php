<?php

// Requires Context

return [
    'fields_not_accepted' => '列 :field 在研究中不被接受。',
];
