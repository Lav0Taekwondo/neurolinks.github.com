<?php

namespace App;

use Litepie\User\User as BaseClass;

class User extends BaseClass
{
}
