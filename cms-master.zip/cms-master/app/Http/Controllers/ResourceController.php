<?php

namespace App\Http\Controllers;

use Litepie\Http\Controllers\ResourceController as BaseController;

class ResourceController extends BaseController
{
}
