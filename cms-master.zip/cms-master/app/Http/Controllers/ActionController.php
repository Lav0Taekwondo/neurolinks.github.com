<?php

namespace App\Http\Controllers;

use Litepie\Http\Controllers\ActionController as BaseController;

class ActionController extends BaseController
{
    
}
