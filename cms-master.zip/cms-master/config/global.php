<?php

return [
    'guard' => 'user.web',
];
